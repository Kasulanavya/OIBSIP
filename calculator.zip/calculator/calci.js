let input = document.getElementById("input");
let output = document.getElementById("output");

let ans = 0;

function appendValue(value) {
  if (value === '√') {
    input.value += 'Math.sqrt(';
  } else {
    input.value += value;
  }
}

function clearAll() {
  input.value = '';
  output.textContent = '0';
}

function deleteChar() {
  input.value = input.value.slice(0, -1);
}

function useAns() {
  input.value += ans;
}

function toggleSign() {
  if (input.value.startsWith('-')) {
    input.value = input.value.slice(1);
  } else {
    input.value = '-' + input.value;
  }
}

function calculate() {
  try {
    let expression = input.value.replace(/x/g, '*').replace(/÷/g, '/');
    let result = eval(expression);
    output.textContent = result;
    ans = result;
  } catch {
    output.textContent = "Error";
  }
}
